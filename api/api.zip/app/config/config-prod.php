<?php

    //acceso a la base de datos
    define('APP_PATH',dirname(dirname(__FILE__)));
    define('DB_HOST','localhost');
    define('DB_USER','ijxclrfi_gpuser');
    define('DB_PASSWORD','wRxB*~5}Ih%7');
    define('DB_NAME','ijxclrfi_gastropack');
    define('URL_PATH','https://entiven.com/api/');
    define('STORAGE_PATH','https://entiven.com/api/');


?>